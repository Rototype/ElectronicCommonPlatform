#include "appdef.h"                        
#include "appstrutt.h"
#include "areadati.h"
extern char CMD_tab[][33];
extern int PAR_val[];
extern char PAR_str[][33];
extern char SlaveUnit[][33];
extern char jsonObj[][33];


//   ################### DEFINE CHE VARIANO IN BASE ALL'APPLICATIVO ############################

#define DIR_IMPIANTO    "etc/" 											// Directory dove risiede il file di configurazione
#define DIR_LOG         "log/" 											// Directory dove ci finiscono i file di log del programma con tutti i messaggi di trace
#define DIR_REPORT      "report/"										// Directory dove risiedono i file di report delle attività del programma
#define DIR_PROGRAMMA   "programma/"									// Directory dove risiedono i file dei programmi di lavoro (ricette)
/*-----------------* File log dei messaggi di trace per debug sistema *-------------- */
#define FILE_LOG        "file.log"										// i file di log si chiamano con la data data "yy_mm_dd_file.log"
#define NETWORK_FILE    "/etc/network/interfaces"						// File per settaggio parametri di rete
#define FILE_IMPIANTO   "impianto.conf"									// Nome file dichiarazione impianto
#define FILE_RX_IMMAGINE "log/imma"										// Nome file di appoggio per la ricezione di un immagine
#define FILE_TX			 "log/invia"									// Nome file di appoggio per la trasmissione su WebSocket
#define FILE_TX_1		 "log/invia1"									// Nome file di appoggio per la trasmissione su WebSocket

#define FILE_DB 		"DBPARA"     	   								// Nome file del DB SQLite3 di default 
#define NOME_TB 		"PARAMETRI"      								// Nome tabella parametri di default

/************************** DEFINE NOMI FILE E DIRECTORY UTILIZZATE DALL'APPLICATIVO ******************************/
#define PARTOT 9
#define ROOTOBJ 5														// Elenco parametri utilizzati all'interno delle stringhe JSON
enum cmdWbSock {
	CMD_UpdateFirmware,
	CMD_UpdateWebSocketFirmware,
	CMD_Restart,
	CMD_UpdateConfiguration,
	CMD_UpdateNetworkConfiguration,
	CMD_ReadDigitalInput,
	CMD_ReadAnalogInput,
	CMD_SetAnalogOutput,
	CMD_SetDCMotor,
	CMD_SetDCMotorPWM,
	CMD_SetDCSolenoid,
	CMD_SetDCSolenoidPWM,
	CMD_SetDigitalOutput,
	CMD_SetStepperMotorSpeed,
	CMD_SetStepperMotorCountSteps,
	CMD_InvertImage,
    CMDTOT 
};
enum cmdSpi {
	Command_None,
	Get_Digital_Input_Status,
	Get_Analog_Input_Status,
	Set_Digital_Output,
	Set_Analog_Output,
	Start_Stepper_Motor,
	Stop_Stepper_Motor,
	Solenoid_activation,
	Solenoid_Deactivation,
	Start_DC_Motor,
	Stop_DC_Motor,
	Read_HWC_Configuration_file,
	Write_HWC_Configuration_file,
	Restart
};

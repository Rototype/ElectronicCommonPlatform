#ifndef _ERROR_MANAGEMENT_
#define _ERROR_MANAGEMENT_

#define REQ_OK           0x00000000UL
#define REQ_ERROR        0x10000000UL

#define E_MARSHAL        0x00010000UL
#define E_UNMARSHAL      0x00020000UL


#endif /* _ERROR_MANAGEMENT_ */
